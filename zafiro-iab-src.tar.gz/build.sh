#!/bin/bash
# ============================================================
# Zafiro IAB Build Script
# Usage: ./build.sh
# Requirements: JDK 17+, Android SDK with platform-37 & build-tools 36+
# ============================================================
set -e

# --- Config ---
JAVA_HOME="${JAVA_HOME:?Set JAVA_HOME to JDK 17+}"
ANDROID_HOME="${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK}"
SDK_DIR="$ANDROID_HOME"

# Point local.properties at the SDK
sed -i.bak "s|sdk.dir=.*|sdk.dir=$SDK_DIR|" local.properties 2>/dev/null || true
echo "sdk.dir=$SDK_DIR" > local.properties

# Accept licenses non-interactively
mkdir -p "$SDK_DIR/licenses"
echo "2456531b023ad2ac298cc95d460598763cc73564" > "$SDK_DIR/licenses/android-sdk-license"
echo "8933bad161af4178b118f24a07e205cbe1c61345" >> "$SDK_DIR/licenses/android-sdk-license"

# Ensure required SDK components are installed (via sdkmanager if available)
if [ -d "$SDK_DIR/cmdline-tools/latest/bin" ]; then
    yes | "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" \
        "platforms;android-37" "build-tools;36.0.0" "platform-tools" 2>/dev/null || true
fi

# --- Build ---
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_SDK_ROOT="$SDK_DIR"

echo "=== Building Zafiro IAB (debug APK) ==="
echo "JDK:      $(java -version 2>&1 | head -1)"
echo "Android:  $SDK_DIR"
echo ""

sh gradlew :app:assembleDebug

echo ""
echo "=== Build complete ==="
APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    echo "APK: $(pwd)/$APK ($(du -h "$APK" | cut -f1))"
    echo ""
    echo "Install with:"
    echo "  adb install $APK"
    echo "  # or copy to phone and use any installer"
else
    echo "ERROR: APK not found at $APK"
    exit 1
fi
