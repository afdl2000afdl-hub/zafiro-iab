# Zafiro IAB — In-App Browser

## What's added

A new `browser/` module implementing a full in-app browser (IAB) for Zafiro:

### New module: `browser/`
- `BrowserTab.kt` — data model (id, url, title, favicon, navigation state, origin)
- `BrowserEngine.kt` — WebView lifecycle + shared CookieManager (persistent login state)
- `BrowserViewModel.kt` — MVI state machine (tab pool, active tab, incognito mode)
- `BrowserPageContent.kt` — Compose UI (tab bar + address bar + WebView + progress)
- `BrowserPage.kt` — `BrowserPageSpec` data class (page descriptor, no ZafiroPage dep)
- `InAppBrowserBridge.kt` — process-wide singleton connecting agent ↔ UI

### New files in `agent-runtime/`
- `chat/agentic/browser/InAppBrowserController.kt` — agent-side port (openTab, listTabs, navigate, closeTab, extractText, evaluateJs, screenshot)
- `chat/agentic/browser/InAppUriRouter.kt` — routes `open_uri` to IAB for http/https
- `chat/agentic/browser/IabNavigator.kt` — port for pushing BrowserPage onto nav stack
- `buildin/impl/BrowserBuiltin.kt` — new `browser` tool (operations: open/list/navigate/close/read/js/screenshot)

### New files in `app/`
- `app/browser/AndroidBrowserController.kt` — Android impl of InAppBrowserController
- `app/browser/AndroidInAppUriRouter.kt` — Android impl of InAppUriRouter
- `app/IabNavigatorRegistry.kt` — holds live IabNavigator (bound in ZafiroApp)
- `app/BrowserViewModelFactory.kt` — factory providing Application context to BrowserViewModel
- `app/ui/route/BrowserPageRoute.kt` — Compose route rendering BrowserPageContent

### Modified files
- `settings.gradle.kts` — adds `:browser` module
- `app/build.gradle.kts` — adds `:browser` dependency
- `agent-runtime/build.gradle.kts` — (no browser dep; clean boundary)
- `agent-runtime/.../BuiltinToolRegistry.kt` — registers `BrowserBuiltin`
- `agent-runtime/.../OpenUriBuiltin.kt` — routes http/https to IAB when available
- `app/AppServices.kt` — installs `InAppUriRouter` service
- `app/ui/ZafiroApp.kt` — registers IabNavigator via LaunchedEffect
- `app/ui/ZafiroPageContent.kt` — dispatches `BrowserPage` to `BrowserPageRoute`
- `app/ui/nav/ZafiroPages.kt` — adds `BrowserPage` ZafiroPage data class

## Build

```bash
export JAVA_HOME=/path/to/jdk-17
export ANDROID_HOME=/path/to/android-sdk
./build.sh
```

Output: `app/build/outputs/apk/debug/app-debug.apk`

## How it works

```
open_uri (https://…)
  → InAppUriRouter.routeInApp() = true
  → AndroidInAppUriRouter.openInBrowser()
  → IabNavigatorRegistry.instance.open(url)
  → ZafiroApp: push BrowserPage(BrowserPageSpec(url))
  → BrowserPageRoute → BrowserPageContent → BrowserViewModel.newTab(url)
  → WebView loads URL
```

Agent `browser` tool:
```
browser(operation="open", url="https://example.com") → tab_id
browser(operation="read", tab_id="...")              → page text
browser(operation="js", tab_id="...", script="...")  → JS result
browser(operation="screenshot", tab_id="...")         → base64 PNG
```
