package com.niki914.zafiro.app.browser

import com.niki914.zafiro.browser.BrowserTab
import com.niki914.zafiro.browser.BrowserViewModel
import com.niki914.zafiro.chat.agentic.browser.InAppBrowserController
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.coroutines.resume

/**
 * [InAppBrowserController] 的 Android 实现：驱动 [BrowserViewModel] 的 WebView tab 池。
 *
 * 由 app 组合根（AppServices）注入，绑定到与 UI 同进程的 BrowserViewModel。
 */
class AndroidBrowserController(
    private val viewModel: BrowserViewModel,
) : InAppBrowserController {

    override fun isAvailable(): Boolean = true

    override fun openTab(url: String?): String? {
        val tab = BrowserTab(
            id = UUID.randomUUID().toString(),
            url = url?.let { android.net.Uri.parse(it) },
            origin = BrowserTab.TabOrigin.AGENT,
        )
        viewModel.addTabInternal(tab)
        return tab.id
    }

    override fun listTabs(): List<InAppBrowserController.TabInfo> =
        viewModel.tabs.value.map {
            InAppBrowserController.TabInfo(
                tabId = it.id,
                url = it.url?.toString(),
                title = it.title,
                origin = if (it.origin == BrowserTab.TabOrigin.AGENT) "agent" else "human",
                isLoading = it.isLoading,
            )
        }

    override fun navigate(tabId: String, url: String): Boolean {
        val tab = viewModel.tabs.value.find { it.id == tabId } ?: return false
        val web = viewModel.webViewFor(tabId)
        web.loadUrl(url)
        tab.url = android.net.Uri.parse(url)
        tab.title = ""
        tab.isLoading = true
        return true
    }

    override fun closeTab(tabId: String): Boolean {
        val existed = viewModel.tabs.value.any { it.id == tabId }
        viewModel.closeTab(tabId)
        return existed
    }

    override fun extractText(tabId: String?): String {
        val target = if (tabId.isNullOrBlank()) viewModel.activeWebView()
            else viewModel.webViewForOrNull(tabId)
        if (target == null) return "No tab available."
        var result = ""
        @Suppress("DEPRECATION")
        target.evaluateJavascript("(document.body && document.body.innerText) || \'\'") { value ->
            result = (value ?: "").removeSurrounding("\"")
        }
        // evaluateJavascript is async; give it a moment
        Thread.sleep(500)
        return result
    }

    override fun evaluateJs(tabId: String, script: String): String? {
        val web = viewModel.webViewForOrNull(tabId) ?: return null
        var result: String? = null
        @Suppress("DEPRECATION")
        web.evaluateJavascript(script) { value ->
            result = value
        }
        Thread.sleep(500)
        return result
    }

    override fun screenshot(tabId: String?): String? {
        // WebView screenshot requires API 30+ and a proven capture approach.
        // Return null for now; the agent falls back to read().
        return null
    }
}
