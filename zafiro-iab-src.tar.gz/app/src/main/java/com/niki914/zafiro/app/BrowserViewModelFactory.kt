package com.niki914.zafiro.app

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.niki914.zafiro.browser.BrowserViewModel

/**
 * Factory for [BrowserViewModel]. Provides the Application context needed to create
 * the WebView engine. Used by `pageViewModel<BrowserViewModel>(factory = ...)` in
 * the BrowserPageRoute.
 */
fun browserViewModelFactory(app: Application): ViewModelProvider.Factory =
    object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(BrowserViewModel::class.java)) {
                return BrowserViewModel(app) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
