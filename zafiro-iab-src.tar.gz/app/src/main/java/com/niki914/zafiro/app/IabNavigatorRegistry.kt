package com.niki914.zafiro.app

import com.niki914.zafiro.chat.agentic.browser.IabNavigator

/**
 * Holds the live [IabNavigator] implementation (bound to the active Activity's NavigationController).
 * Installed in ZafiroApp when the browser page is reachable.
 */
object IabNavigatorRegistry {
    var instance: IabNavigator? = null
}
