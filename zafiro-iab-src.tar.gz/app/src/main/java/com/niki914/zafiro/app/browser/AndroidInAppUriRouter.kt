package com.niki914.zafiro.app.browser

import android.net.Uri
import com.niki914.zafiro.browser.InAppBrowserBridge
import com.niki914.zafiro.chat.agentic.browser.IabNavigator
import com.niki914.zafiro.chat.agentic.browser.InAppUriRouter

/**
 * [InAppUriRouter] 的 Android 实现：
 * - 只把 http/https 路由进 IAB
 * - 打开 = 经 [IabNavigator] 推 BrowserPage + 经 [InAppBrowserBridge] 建 agent tab
 */
class AndroidInAppUriRouter(
    private val navigator: IabNavigator?,
) : InAppUriRouter {

    override fun routeInApp(uri: Uri): Boolean =
        when (uri.scheme?.lowercase()) {
            "http", "https" -> true
            else -> false
        }

    override fun openInBrowser(url: String) {
        // 1. Create agent tab in the ViewModel (if IAB is already open)
        InAppBrowserBridge.instance?.newTab(url, agentOrigin = true)
        // 2. Push the BrowserPage onto the nav stack
        navigator?.open(url)
    }
}
