package com.niki914.zafiro.app.ui.route

import androidx.compose.runtime.Composable
import com.niki914.zafiro.app.ui.nav.BrowserPage
import com.niki914.zafiro.browser.BrowserPageContent
import com.niki914.zafiro.browser.BrowserPageSpec

/**
 * IAB 路由：渲染 [BrowserPageContent]。
 * spec 的 onNewTab 回调推新的 BrowserPage（同 routeKey 族）。
 */
@Composable
internal fun BrowserPageRoute(
    page: BrowserPage,
    onPush: (com.niki914.zafiro.app.ui.nav.ZafiroPage) -> Unit,
) {
    BrowserPageContent(
        spec = page.spec,
        onNewTab = { url ->
            onPush(BrowserPage(BrowserPageSpec(url)))
        },
    )
}
