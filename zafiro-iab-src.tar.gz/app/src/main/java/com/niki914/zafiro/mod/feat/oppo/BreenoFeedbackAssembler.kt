package com.niki914.zafiro.mod.feat.oppo

import com.niki914.zafiro.api.util.tryOrNull
import com.niki914.xposed.runtime.util.call

object BreenoFeedbackAssembler {
    fun attachIfNeeded(bean: Any) {
        val feedbackClassName = BreenoConfigProvider.RenderCard.feedbackInfoClass
        val footerClassName = BreenoConfigProvider.RenderCard.footerInfoClass
        val beanSetFeedbackInfoMethod = BreenoConfigProvider.RenderCard.beanSetFeedbackInfoMethod
        val feedbackSetFooterInfoMethod =
            BreenoConfigProvider.RenderCard.feedbackSetFooterInfoMethod
        val footerSetCopyFlagMethod = BreenoConfigProvider.RenderCard.footerInfoSetCopyFlagMethod
        val footerSetUpvoteFlagMethod =
            BreenoConfigProvider.RenderCard.footerInfoSetUpvoteFlagMethod

        val classLoader = bean.javaClass.classLoader
        val feedback = instantiate(feedbackClassName, classLoader) ?: return
        val footer = instantiate(footerClassName, classLoader) ?: return

        footer.call<Unit>(
            footerSetCopyFlagMethod,
            BreenoConfigProvider.RenderCard.feedbackCopyFlagEnabled
        )
        footer.call<Unit>(
            footerSetUpvoteFlagMethod,
            BreenoConfigProvider.RenderCard.feedbackUpvoteFlagEnabled
        )
        feedback.call<Unit>(feedbackSetFooterInfoMethod, footer)
        bean.call<Unit>(beanSetFeedbackInfoMethod, feedback)
    }

    private fun instantiate(className: String, classLoader: ClassLoader?): Any? = tryOrNull {
        val clazz = Class.forName(className, false, classLoader)
        clazz.getDeclaredConstructor().newInstance()
    }
}
